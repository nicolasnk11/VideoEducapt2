//
//  Chavenho.swift
//  VideoEduca
//
//  Created by User on 15/09/23.
//

import SwiftUI

struct Chaves: View {
    var body: some View{
        
        HStack{
            Image("Chavenho")
                .resizable()
                .frame(width: 450, height: 250)
                .cornerRadius(10)
        
            
        }
        VStack{
            Text("Cancelar mi hermanos...")
                .font(.headline)
                .foregroundColor(.white)
                .bold()
        }
    }
}


struct Chavenho_Previews: PreviewProvider {
    static var previews: some View {
        Chaves()
    }
}
