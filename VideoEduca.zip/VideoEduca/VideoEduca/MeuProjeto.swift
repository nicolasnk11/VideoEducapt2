//
//  MeuProjeto.swift
//  VideoEduca
//
//  Created by User on 15/09/23.
//

import SwiftUI

struct MeuProjeto: View{
    var body: some View{
        
        ZStack{
            Color.green
                .edgesIgnoringSafeArea(.all)
            VStack(spacing: 35){
                Text("OBJETIVO PRINCIPAL!")
                    .font(.system(size: 44))
                    .foregroundColor(.white)
                    .bold()
                                

                    }
                }
            }
        }
struct MeuProjeto_Previews: PreviewProvider {
    static var previews: some View {
        MeuProjeto()
    }
}
