//
//  ContentView.swift
//  VideoEduca
//
//  Created by User on 12/09/23.
//

import SwiftUI

struct ContentView: View{
    var body: some View{
        
        ZStack{
            Color.blue
                .edgesIgnoringSafeArea(.all)
            VStack(spacing: 35){
                Text("OBJETIVO PRINCIPAL!")
                    .font(.system(size: 44))
                    .foregroundColor(.white)
                    .bold()
                HStack{
                    Image("candace")
                        .resizable()
                        .frame(width: 150, height: 150)
                        .cornerRadius(10)
                    VStack{
                        ZStack{
                            Image("phineas")
                                .resizable()
                                .frame(width: 150, height: 150)
                                .cornerRadius(10)
                            Image("x")
                                .resizable()
                                .frame(width: 100, height: 100)
                                .cornerRadius(10)
                            
                        }
                        ZStack{
                            Image("ferb")
                                .resizable()
                                .frame(width: 150, height: 150)
                                .cornerRadius(10)
                            Image("x")
                                .resizable()
                                .frame(width: 100, height: 100)
                                .cornerRadius(10)
                            
                        }
                    }
                }
                VStack{
                    Text("Cancelar mi hermanos...")
                        .font(.headline)
                        .foregroundColor(.white)
                        .bold()
                    Button{
                        
                    } label: {
                        Text("a frente")
                            .font(.headline)
                            .foregroundColor(.blue)
                            .padding(.vertical, 10)
                            .padding(.horizontal, 10)
                            .background(Color.white)
                            .cornerRadius(10)
                        
                    }
                }
            }
        }
    }
}
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
