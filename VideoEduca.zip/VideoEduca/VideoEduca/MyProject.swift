//
//  MyProject.swift
//  VideoEduca
//
//  Created by User on 12/09/23.
//

import SwiftUI
import Foundation

struct ContentImages: View {
    var body: some View{
        
        HStack{
            Image("candace")
                .resizable()
                .frame(width: 150, height: 150)
                .cornerRadius(10)
            VStack{
                ZStack{
                    Image("phineas")
                        .resizable()
                        .frame(width: 150, height: 150)
                        .cornerRadius(10)
                    Image("x")
                        .resizable()
                        .frame(width: 100, height: 100)
                        .cornerRadius(10)
                    
                }
                ZStack{
                    Image("ferb")
                        .resizable()
                        .frame(width: 150, height: 150)
                        .cornerRadius(10)
                    Image("x")
                        .resizable()
                        .frame(width: 100, height: 100)
                        .cornerRadius(10)
                    
                }
            }
        }
    }
}
